package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Controller {

    @FXML
    private ToggleGroup answers;

    @FXML
    private Text question_text;

    @FXML
    private RadioButton radio_btn_1;

    @FXML
    private RadioButton radio_btn_2;

    @FXML
    private RadioButton radio_btn_3;

    @FXML
    private RadioButton radio_btn_4;

    @FXML
    private Button answerBtn;

    private Questions[] questions = new Questions[] {
            new Questions("В якому з перелічених випадків водій здійснив вимушену зупинку?", new String[] {"Зупинився на узбіччі через прокол колеса.", "Всі відповіді правельні.", "Зупинився,щоб надати допомогу пасажиру.", "Зупинився на смузі руху через засліплення фарами зустрічного автомобіля."}),
            new Questions("Недостатньою видимістю вважається:", new String[] {"Обмежена оглядовість менша 300 м.", "Небезпечний поворот,небезпечний підйом,небезпечний спуск.", "Видимість дороги в напрямку руху менше 300 метрів, обмежена поворотом.", "Видимість дороги в напрямку руху менше 300м у сутінках,в умовах дощу і.п."}),
            new Questions("З якого боку дозволено виконати випередження на проїзній частині?", new String[] {"Заборонено.", "Тільки з правого боку.", "Тільки з лівого боку.", "З будь-якого боку по суміжній смузі з дотриманням безпечного інтервалу."}),
            new Questions("Яка максимально дозволена швидкість автомобіля поза населеними пунктами?", new String[] {"120 км/год", "40 км/год", "100 км/год", "90 км/год"}),
            new Questions("Які фактори можуть призвести до засліплення водія?", new String[] {"Інтенсивний снігопад.", "Сильна злива.", "Мокрий сніг.", "Світло."}),
            new Questions("Яка максимально дозволена швидкість автомобіля в населеному пункті? ", new String[] {"120 км/год", "90 км/год", "60 км/год", "50 км/год"})
    };

    private int nowQuestion = 0, correctAnswers;
    private String nowCorrectAnswer;

    @FXML
    public void initialize() {
        nowCorrectAnswer = questions[nowQuestion].correctAnswer();

        answerBtn.setOnAction(e -> {
            RadioButton selectedRadioButton = (RadioButton) answers.getSelectedToggle();
            if(selectedRadioButton != null) {
                String toogleGroupValue = selectedRadioButton.getText();

                if(toogleGroupValue.equals(nowCorrectAnswer)) {
                    System.out.println("Відповідь правельна");
                    correctAnswers++;
                } else {
                    System.out.println("Відповідь неправельна");
                }

                if(nowQuestion + 1 == questions.length) {
                    radio_btn_1.setVisible(false);
                    radio_btn_2.setVisible(false);
                    radio_btn_3.setVisible(false);
                    radio_btn_4.setVisible(false);
                    answerBtn.setVisible(false);

                    question_text.setText("Ви відповіли правельно на " + correctAnswers + " з " + questions.length + " питаннь!");
                } else {
                    nowQuestion++;
                    nowCorrectAnswer = questions[nowQuestion].correctAnswer();

                    question_text.setText(questions[nowQuestion].getQuestion());
                    String[] answers = questions[nowQuestion].getAnswers();


                    List<String> intList = Arrays.asList(answers);

                    Collections.shuffle(intList);

                    radio_btn_1.setText(intList.get(0));
                    radio_btn_2.setText(intList.get(1));
                    radio_btn_3.setText(intList.get(2));
                    radio_btn_4.setText(intList.get(3));

                    selectedRadioButton.setSelected(false);
                }

            }
        });
    }

}

